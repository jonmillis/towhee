#!/bin/bash
#SBATCH --partition=fat
#SBATCH --job-name=myjob
#SBATCH -t 24:00:00
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=28
#SBATCH --mail-user=duckid@uoregon.edu
#SBATCH --mail-type=begin
#SBATCH --mail-type=end
#SBATCH --account=ch447_547

../../Source/towhee
